#include <stdio.h>
void main ()
{
	 FILE *fp = fopen ("file.txt","a");
     char ch;
     fprintf(fp,"\n ne3e line added ");
     fclose(fp);
}
