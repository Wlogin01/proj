#include <stdio.h>
#include <sys/stat.h>
#include <time.h>
int main() {
    struct stat attr;
    stat("file1.txt", &attr);
    printf("Last modified time: %s", ctime(&attr.st_mtime));
}

