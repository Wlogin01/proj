#include <stdio.h>

int main() {
    // Copy content from file2.txt to file1.txt
    FILE *source = fopen("file2.txt", "r");
    FILE *dest = fopen("file1.txt", "w");
    
    if (source == NULL || dest == NULL) {
        printf("Error opening files.\n");
        return 1;
    }
    
    char ch;
    while ((ch = fgetc(source)) != EOF) {
        fputc(ch, dest);
    }
    
    fclose(source);
    fclose(dest);

    // Print content of file1.txt
    dest = fopen("file1.txt", "r");
    if (dest == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    printf("Content of file1.txt:\n");
    while ((ch = fgetc(dest)) != EOF) 
	{
        putchar(ch);
    }

    fclose(dest);

    return 0;
}





