#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *src = fopen("file1.txt", "r");
    FILE *temp = fopen("temp.txt", "w");
    char buffer[1024];
    int lineToDelete = 2;
    int currentLine = 1;

    if (!src || !temp) {
        printf("Error opening files.\n");
        return 1;
    }

    while (fgets(buffer, sizeof(buffer), src) != NULL) {
        if (currentLine != lineToDelete) {
            fputs(buffer, temp);
        }
        currentLine++;
    }

    fclose(src);
    fclose(temp);
    remove("file1.txt");
    rename("temp.txt", "file1.txt");

    return 0;
}

