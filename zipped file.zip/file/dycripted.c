#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *encryptedFile = fopen("var2.txt", "r");
    FILE *decryptedFile = fopen("decrypted.txt", "w");
    if (!encryptedFile || !decryptedFile) {
        printf("File operation error\n");
        return 1;
    }

    char ch;
    int key = 3; // Same shift amount as used for encryption
    while ((ch = fgetc(encryptedFile)) != EOF) {
        if (ch >= 'a' && ch <= 'z') {
            fputc(((ch - 'a' - key + 26) % 26) + 'a', decryptedFile);
        } else if (ch >= 'A' && ch <= 'Z') {
            fputc(((ch - 'A' - key + 26) % 26) + 'A', decryptedFile);
        } else {
            fputc(ch, decryptedFile);
        }
    }

    fclose(encryptedFile);
    fclose(decryptedFile);
    return 0;
}

