#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file = fopen("var2.txt", "r");
    FILE *encryptedFile = fopen("encrypted.txt", "w");
    if (!file || !encryptedFile) {
        printf("File operation error\n");
        return 1;
    }

    char ch;
    int key = 3; // Shift amount for Caesar cipher
    while ((ch = fgetc(file)) != EOF) {
        if (ch >= 'a' && ch <= 'z') {
            fputc(((ch - 'a' + key) % 26) + 'a', encryptedFile);
        } else if (ch >= 'A' && ch <= 'Z') {
            fputc(((ch - 'A' + key) % 26) + 'A', encryptedFile);
        } else {
            fputc(ch, encryptedFile);
        }
    }

    fclose(file);
    fclose(encryptedFile);
    return 0;
}

