#include <stdio.h>

int main() {
    FILE *file = fopen("var.txt", "r"); // Open the file for reading
    if (!file) {
        perror("Failed to open file for reading");
        return 1;
    }

    char name[50];
    int age;
    float height;

    // Read the name, age, and height from file
    fscanf(file, "%49s %d %f", name, &age, &height);

    printf("Name: %s\nAge: %d\nHeight: %.2f\n", name, age, height);

    fclose(file); // Close the file
    return 0;
}

