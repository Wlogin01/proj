#include <stdio.h>

typedef struct {
    char name[50];
    int age;
    float height;
} Student;

int main() {
    FILE *file = fopen("students.txt", "w");
    if (!file) {
        perror("Failed to open file for writing");
        return 1;
    }

    Student students[10] = {
        {"John Doe", 20, 5.9},
        {"Jane Doe", 22, 5.5},
        // Assume more students are filled in here...
        {"Student Nine", 19, 6.0},
        {"Student Ten", 21, 5.7}
    };
int i;
    for (i = 0; i < 10; i++) 
	{
        fprintf(file, "%s %d %.2f\n", students[i].name, students[i].age, students[i].height);
    }

    fclose(file);
    return 0;
}

