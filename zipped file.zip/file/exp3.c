#include <stdio.h>

int main() {
    FILE *file = fopen("user_info.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return 1;
    }
int i;
    for ( i = 0; i < 5; i++) {
        char name[100], address[100];
        int id;

        printf("Enter name for user %d: ", i+1);
        scanf("%s", name);

        printf("Enter ID for user %d: ", i+1);
        scanf("%d", &id);

        printf("Enter address for user %d: ", i+1);
        scanf("%s", address);

        fprintf(file, "User %d:\nName: %s\nID: %d\nAddress: %s\n\n", i+1, name, id, address);
    }

    fclose(file);
    printf("User information written to file.\n");

    // Display the information from the file
    file = fopen("user_info.txt", "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        return 1;
    }

    char line[256];
    printf("\nUser Information:\n");
    while (fgets(line, sizeof(line), file)) {
        printf("%s", line);
    }
    fclose(file);

    return 0;
}

