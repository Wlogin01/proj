#include <stdio.h>
int main() {
    FILE *first = fopen("file1.txt", "r");
	FILE *second = fopen("file2.txt", "r");
	FILE *merged = fopen("merged.txt", "w");
	
    char ch;
    
    while ((ch = fgetc(first)) != EOF)
	 fputc(ch, merged);
	 
	
    while ((ch = fgetc(second)) != EOF) 
	fputc(ch, merged);
	
    fclose(first);
    fclose(second);
    fclose(merged);
}

