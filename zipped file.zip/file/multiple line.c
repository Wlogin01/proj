#include <stdio.h>
void main ()
{
	 FILE *source = fopen ("file.txt","w");
	 fputs(" \n hwllo new few lines added to the file ");
	 
	 fclose(source);
}
