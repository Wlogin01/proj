#include <stdio.h>
int main() {
    FILE *fp = fopen("file2.txt", "r");
    int lines = 0;
    char ch;
    while ((ch = fgetc(fp)) != EOF) {
        putchar(ch);
        if (ch == '\n') lines++;
    }
    fclose(fp);
    printf("\nNumber of lines: %d\n", lines);
}

