#include <stdio.h>
void main ()
{
 FILE *fp = fopen ("file.txt","r");
 char ch;
 while ((ch=fgetc(fp)!= EOF))
 putchar(ch);
 fclose(fp);
}
