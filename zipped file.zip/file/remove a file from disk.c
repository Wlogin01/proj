#include <stdio.h>
int main() 
{

    // Create a file
    FILE *file = fopen("file3.txt", "w");
    if (file == NULL)
	 {
        printf("Error creating file.\n");
        return 1;
    }
    printf("File created successfully.\n");

    // Close the file
    fclose(file);

    // Remove the file from disk
    if (remove("example.txt") != 0)
	 {
        printf("Error removing file.\n");
        return 1;
    }
    printf("File removed successfully.\n");

    return 0;
}

