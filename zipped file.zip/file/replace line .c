#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char filePath[] = "file1.txt";
    FILE *file = fopen(filePath, "r+");
    if (!file) {
        perror("File opening failed");
        return EXIT_FAILURE;
    }

    // Assuming the file content is small and can fit into this buffer
    char content[1024] = {0};
    fread(content, sizeof(char), 1024, file);

    // Simple string replacement for demonstration, not safe for different lengths
    char *pos;
    while ((pos = strstr(content, "oldText")) != NULL) {
        // Example assumes "oldText" and "newText" are the same length
        strncpy(pos, "newText", strlen("newText"));
    }

    // Overwrite the file from the beginning
    fseek(file, 0, SEEK_SET);
    fwrite(content, sizeof(char), strlen(content), file);
    fclose(file);

    return 0;
}

