#include <stdio.h>

int main() {
    // Open a file for writing
    FILE *file = fopen("example.txt", "w");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Writing to the file using fprintf
    fprintf(file, "Hello, file!\n");

    // Closing the file
    fclose(file);

    // Reopen the file for reading
    file = fopen("example.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Reading from the file using fgets
    char buffer[100];
    fgets(buffer, 100, file);
    printf("Content read from file: %s", buffer);

    // Closing the file
    fclose(file);

    // Reading from standard input using scanf
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);
    printf("Number entered: %d\n", number);

    // Reading from standard input using getchar
    printf("Enter a character: ");
    char ch = getchar();
    printf("Character entered: ");
    putchar(ch);
    printf("\n");

    // Writing to standard output using printf
    printf("This is printed to standard output.\n");

    // Opening a file for appending
    file = fopen("example.txt", "a");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Writing to the file using fputc
    fputc('A', file);

    // Closing the file
    fclose(file);

    // Reopen the file for reading
    file = fopen("example.txt", "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Reading from the file using fscanf
    char chFromFile;
    fscanf(file, "%c", &chFromFile);
    printf("Character read from file: %c\n", chFromFile);

    // Closing the file
    fclose(file);

    return 0;
}

