#include <stdio.h>

int main() {
    FILE *fp = fopen("var.txt", "r");
    if (fp == NULL) {
        printf("Error opening file var.txt for reading.\n");
        return 1;
    }

    char content[100];
    if (fgets(content, 100, fp) != NULL)
	 {
        printf("Content read from var.txt: %s\n", content);
    } else
	 {
        printf("Error reading content from var.txt.\n");
        fclose(fp);
        return 1;
    }
    
    fclose(fp);

    fp = fopen("var2.txt", "w");
    if (fp == NULL)
	 {
        printf("Error opening file var2.txt for writing.\n");
        return 1;
    }

    fputs(content, fp);
    printf("Content written to var2.txt.\n");

    fclose(fp);

    return 0;
}


