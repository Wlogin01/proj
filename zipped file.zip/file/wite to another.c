#include <stdio.h>
void main ()
{
	 FILE *source = fopen ("file.txt","r");
	 FILE *dest = fopen ("file2.txt","w");
	 
     int ch;
     ch=fgetc(source);
     while (ch!=EOF)
     fputc(ch,dest);
     fclose(source);
     fclose(dest);
	 }
