#include <stdio.h>
int main() {
    FILE *fp = fopen("file2.txt", "r");
    int words = 0, chars = 0;
    char ch;
    while ((ch = fgetc(fp)) != EOF)
	 {
        chars++;
        if (ch == ' ' || ch == '\n')
		 words++;
    }
    fclose(fp);
    printf("Words: %d, Characters: %d\n", words, chars);
}

