#include <stdio.h>
void main ()
{
	FILE *fp = fopen("file.txt","w");
	if (fp==NULL)
	{
		printf("error ");
	}
	fprintf(fp,"hello world");
	printf("finished");
	fclose(fp);
}
